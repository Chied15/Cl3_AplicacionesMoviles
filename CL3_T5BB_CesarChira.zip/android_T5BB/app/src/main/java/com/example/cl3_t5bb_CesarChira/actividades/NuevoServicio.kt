package com.example.cl3_t5bb_CesarChira.actividades

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.cl3_t5bb_CesarChira.R

class NuevoServicio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.nuevoservicioactivity)
    }
}