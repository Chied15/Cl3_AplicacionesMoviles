package com.example.cl3_t5bb_CesarChira.tools

class Constantes {
    companion object
    {
        const val ENDPOINT = "http://cibertec202021-001-site1.etempurl.com/Servicio/"
        const val GETLISTAR_SERVICIO = "Listar"
        const val GETLISTARKEY_SERVICIO = "ListarKey"
        const val GETRegistraModifica_SERVICIO = "RegistraModifica"
        const val GETElimina_SERVICIO = "Elimina"
    }
}